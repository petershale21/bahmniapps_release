Bahmni.Clinical.StateNameEvenTypeMap = {
    "search.patientsearch": "VIEWED_CLINICAL_PATIENT_SEARCH",
    "patient.dashboard.show": "VIEWED_CLINICAL_DASHBOARD",
    "patient.dashboard.show.observations": "VIEWED_OBSERVATIONS_TAB",
    "patient.dashboard.show.diagnosis": "VIEWED_DIAGNOSIS_TAB",
    "patient.dashboard.show.treatment.page": "VIEWED_TREATMENT_TAB",
    "patient.dashboard.show.disposition": "VIEWED_DISPOSITION_TAB",
    "patient.dashboard.show.summary": "VIEWED_DASHBOARD_SUMMARY",
    "patient.dashboard.show.orders": "VIEWED_ORDERS_TAB",
    "patient.dashboard.show.bacteriology": "VIEWED_BACTERIOLOGY_TAB",
    "patient.dashboard.show.investigation": "VIEWED_INVESTIGATION_TAB",
    "patient.visit.summaryprint": "VIEWED_SUMMARY_PRINT",
    "patient.dashboard.visit": "VIEWED_VISIT_DASHBOARD",
    "patient.dashboard.visitPrint": "VIEWED_VISIT_PRINT",
    "patient.dashboard.observation": "VIEWED_DASHBOARD_OBSERVATION",
    "patient.patientProgram.show": "VIEWED_PATIENTPROGRAM"
};
