'use strict';

var Bahmni = Bahmni || {};
Bahmni.IPD = Bahmni.IPD || {};

angular.module('bahmni.ipd', ['bahmni.common.conceptSet', 'bahmni.common.logging']);
