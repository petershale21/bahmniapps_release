'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.DrugOrdersSection = Bahmni.Common.DisplayControl.DrugOrdersSection || {};

angular.module('bahmni.common.displaycontrol.drugOrdersSection', []);
