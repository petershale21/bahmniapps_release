'use strict';

angular.module('bahmni.common.displaycontrol', []);
angular.module('bahmni.common.displaycontrol.documents', []);
