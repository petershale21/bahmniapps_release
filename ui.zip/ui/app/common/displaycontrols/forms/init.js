'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.forms = Bahmni.Common.DisplayControl.forms || {};

angular.module('bahmni.common.displaycontrol.forms', []);
