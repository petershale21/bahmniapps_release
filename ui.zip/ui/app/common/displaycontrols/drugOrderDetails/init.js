'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.DrugOrderDetails = Bahmni.Common.DisplayControl.DrugOrderDetails || {};

angular.module('bahmni.common.displaycontrol.drugOrderDetails', []);
