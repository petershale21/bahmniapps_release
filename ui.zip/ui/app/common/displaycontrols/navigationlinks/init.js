'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.navigationLinks = Bahmni.Common.DisplayControl.navigationLinks || {};

angular.module('bahmni.common.displaycontrol.navigationlinks', ['ui.router', 'ui.router.util']);
