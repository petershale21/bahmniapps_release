'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.DrugOGram = Bahmni.Common.DisplayControl.DrugOGram || {};

angular.module('bahmni.common.displaycontrol', []);
angular.module('bahmni.common.displaycontrol.chronicTreatmentChart', []);
