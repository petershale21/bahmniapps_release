'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.hint = Bahmni.Common.DisplayControl.hint || {};

angular.module('bahmni.common.displaycontrol.hint', []);
