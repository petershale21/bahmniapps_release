'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.bacteriologyresults = Bahmni.Common.DisplayControl.bacteriologyresults || {};

angular.module('bahmni.common.displaycontrol.bacteriologyresults', []);

