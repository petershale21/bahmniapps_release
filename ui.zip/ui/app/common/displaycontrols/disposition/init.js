'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.Disposition = Bahmni.Common.DisplayControl.Disposition || {};

angular.module('bahmni.common.displaycontrol.disposition', []);
