'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.DisplayControl = Bahmni.Common.DisplayControl || {};
Bahmni.Common.DisplayControl.Custom = Bahmni.Common.DisplayControl.Custom || {};

angular.module('bahmni.common.displaycontrol.custom', []);
