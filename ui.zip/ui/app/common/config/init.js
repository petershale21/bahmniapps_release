angular.module('bahmni.common.config', []);
