angular.module('bahmni.common.bacteriologyresults', []);
